#include <stdio.h>
int main()
{
    printf("The numbers from 10 to 100 are :\n");
    for (int i = 10; i <= 100; i++)
    {
        printf("%d ", i);
    }
    return 0;
}